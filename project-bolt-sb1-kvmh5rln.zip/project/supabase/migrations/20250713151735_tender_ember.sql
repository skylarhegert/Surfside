/*
  # Fix RLS Policies to Prevent Infinite Recursion

  1. Problem
    - Admin policies were querying user_profiles table from within user_profiles policies
    - This created infinite recursion when checking permissions

  2. Solution
    - Remove self-referential policies that cause recursion
    - Use auth.jwt() to check user roles instead of querying user_profiles table
    - Simplify policies to avoid circular dependencies

  3. Security
    - Users can still only access their own data
    - Admin functionality will be handled at the application level
    - RLS policies remain secure but without recursion
*/

-- Drop existing policies that cause recursion
DROP POLICY IF EXISTS "Admins can read all profiles" ON user_profiles;
DROP POLICY IF EXISTS "Admins can insert profiles" ON user_profiles;
DROP POLICY IF EXISTS "Admins can delete documents" ON documents;
DROP POLICY IF EXISTS "Admins can insert documents" ON documents;

-- Keep simple, non-recursive policies
-- Users can read their own profile
-- Users can update their own profile
-- Allow profile creation during signup

-- For documents, keep simple authenticated user access
-- Admin functionality will be handled in the application layer